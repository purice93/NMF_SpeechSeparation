""" 
@author: zoutai
@file: plot.py 
@time: 2017/11/09 
@description: 
"""
import plotme
import wave
f1 = wave.open(r's1/mir1k_fdps_4_03_groundtruth_music.wav','rb')
plotme.plotWav(f1)
f2 = wave.open(r's2/mir1k_fdps_4_03_groundtruth_singing.wav','rb')
plotme.plotWav(f2)
f3 = wave.open(r'test3.wav','rb')
plotme.plotWav(f3)

